export type Product = {
  id: string;
  name: string;
  slug: string;
  price: number;
  image: string;
  description?: string;
};

export const products: Product[] = [
  { id: "1", name: "Zapatillas Runner", slug: "zapatillas-runner", price: 199.9, image: "/shoes-1.jpg" },
  { id: "2", name: "Mochila Urbana", slug: "mochila-urbana", price: 129.0, image: "/bag-1.jpg" },
];
