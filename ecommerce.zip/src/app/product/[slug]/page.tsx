import { products } from "@/data/products";
import { notFound } from "next/navigation";
import AddToCartButton from "@/components/AddToCartButton";

export default function ProductPage({ params }: { params: { slug: string } }) {
  const product = products.find(p => p.slug === params.slug);
  if (!product) return notFound();

  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="text-2xl font-bold">{product.name}</h1>
      <p className="mt-2">Precio: S/ {product.price.toFixed(2)}</p>
      <AddToCartButton product={product} className="mt-4" />
    </main>
  );
}
